package enumerations;

/**
 * Enumération des matériaux.
 * 
 * @author Grégory NAM
 * @author Hugo CHALIK
 * @author Luca BEVILACQUA
 * @author Ahmadou Bamba MBAYE.
 *
 */

public enum Materiaux {

	BRONZE, ARGENT, OR, PLAQUE_OR;

}
